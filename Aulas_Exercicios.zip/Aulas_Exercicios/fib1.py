"""
Exemplo de Fibonacci interativo.
"""

# def fibonacci(n):
#     a, b = 0, 1

#     for _ in range(n):
#         a, b = b, a + b

#     return a


# resultado = fibonacci(20999)
# print(f"F({resultado})")


def fibonacci_interativo(n):
    a, b = 0, 1

    for _ in range(n):
        a, b = b, a + b

    return a

def fibonacci_recursivo(n):
    if n <= 1:
        return 1
        
    return fibonacci_interativo(n - 1) + fibonacci_recursivo(n - 2)

for n in range(900):
    print(fibonacci_recursivo(n), end=" ")