"""
Representação do mapa da Romênia, junto com a heurística - distância
em linha reta do vétice até Bucareste.
"""

class Vertex:
    def __init__(self, label: str, target_distance: int):
        self.label = label
        self.target_distance = target_distance
        self.adjacent = []
        self.visited = False

    def add_adjacent(self, adjacent):
        self.adjacent.append(adjacent)
    
    def show_adjacent(self):
        for adjacent in self.adjacent:
            print(f"Adjacente: {adjacent.vertex.label} - {adjacent.cost} Km")
            
        
class Adjacent:
    def __init__(self, vertex, cost):
        self.vertex = vertex
        self.cost = cost

        #NEW
        self.star_distance = vertex.target_distance + cost


class Romania:
    arad = Vertex("Arad", 366)
    zerind = Vertex("Zerind", 374)
    oradea = Vertex("Oradea", 380)
    sibiu = Vertex("Sibiu", 253)
    timisoara = Vertex("Timisoara",329)
    lugoj = Vertex("Lugoj", 244)
    mehadia = Vertex("Mehadia", 241)
    dobreta = Vertex("Dobreta", 242)
    craiova = Vertex("Craiova", 160)
    rimicu = Vertex("Rimicu Vilcea", 193)
    fagaras = Vertex("Fagaras", 178)
    pitesti = Vertex("Pistesti", 98)
    giurgiu = Vertex("Giurgiu", 77)
    bucarest = Vertex("Bucarest", 0)

    arad.add_adjacent(Adjacent(zerind, 75))         
    arad.add_adjacent(Adjacent(timisoara, 118))
    arad.add_adjacent(Adjacent(sibiu, 140))  

    zerind.add_adjacent(Adjacent(oradea, 71))        
    zerind.add_adjacent(Adjacent(arad, 75))   

    oradea.add_adjacent(Adjacent(zerind, 71))        
    oradea.add_adjacent(Adjacent(sibiu, 151))        

    sibiu.add_adjacent(Adjacent(rimicu, 80))        
    sibiu.add_adjacent(Adjacent(fagaras, 99))        
    sibiu.add_adjacent(Adjacent(arad, 40))        
    sibiu.add_adjacent(Adjacent(oradea, 158))

    timisoara.add_adjacent(Adjacent(lugoj, 111))        
    timisoara.add_adjacent(Adjacent(arad, 118))        

    lugoj.add_adjacent(Adjacent(mehadia, 70))        
    lugoj.add_adjacent(Adjacent(timisoara, 111))
    
    mehadia.add_adjacent(Adjacent(lugoj, 70))        
    mehadia.add_adjacent(Adjacent(dobreta, 75))
    
    dobreta.add_adjacent(Adjacent(mehadia, 75))        
    dobreta.add_adjacent(Adjacent(craiova, 120))        

    craiova.add_adjacent(Adjacent(dobreta, 120))        
    craiova.add_adjacent(Adjacent(pitesti, 138))      
    craiova.add_adjacent(Adjacent(rimicu, 146))

    rimicu.add_adjacent(Adjacent(craiova, 146))
    rimicu.add_adjacent(Adjacent(sibiu, 80))
    rimicu.add_adjacent(Adjacent(pitesti, 97))

    fagaras.add_adjacent(Adjacent(sibiu, 99))
    fagaras.add_adjacent(Adjacent(bucarest, 211))
  
    pitesti.add_adjacent(Adjacent(craiova, 138))
    pitesti.add_adjacent(Adjacent(rimicu, 97))
    pitesti.add_adjacent(Adjacent(bucarest, 101))

    bucarest.add_adjacent(Adjacent(pitesti, 101))
    bucarest.add_adjacent(Adjacent(giurgiu, 90))
    bucarest.add_adjacent(Adjacent(fagaras, 211))
        